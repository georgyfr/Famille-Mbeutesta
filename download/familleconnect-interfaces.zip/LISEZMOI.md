# FamilleConnect — Pack d'interfaces pour revue

**Objet :** comparer les maquettes HTML d'origine avec l'interface réellement construite (Next.js), et décider des axes d'amélioration.

---

## 1. Contenu du pack

```
├── LISEZMOI.md                        ← ce guide
├── 01-maquettes-originales/           ← les maquettes HTML de la documentation d'origine
│   ├── FamilleConnect_Maquette_Interactive.html   (97 Ko — maquette navigable complète)
│   └── FamilleConnect_Pitch_Deck.html             (43 Ko — présentation du projet)
└── 02-interface-actuelle/             ← le code source COMPLET de l'application telle qu'elle tourne aujourd'hui
    ├── src/
    │   ├── app/
    │   │   ├── page.tsx               (57 lignes — point d'entrée : bascule Auth ↔ Dashboard)
    │   │   ├── layout.tsx             (48 lignes — head PWA, meta, theme)
    │   │   ├── globals.css            (183 lignes — DESIGN SYSTEM : crème #F4F1E9, vert #2A4A3A, or #C89F62, serif Georgia, watermark arbre)
    │   │   └── api/                   (13 routes API — 1 027 lignes)
    │   │       ├── auth/              session, verify-code, otp, activate, passkey, pin, recovery, logout
    │   │       ├── notifications/     list, read, read-all, préférences (digest 19h)
    │   │       ├── push/              abonnement VAPID + push test
    │   │       ├── devices/           liste + révocation des appareils
    │   │       ├── security-log/      journal de sécurité
    │   │       └── admin/members/     pré-enregistrement + génération codes FC-XXXX-XXXX
    │   ├── components/fc/
    │   │   ├── auth-flow.tsx          (771 lignes — TOUS LES ÉCRANS DE CONNEXION)
    │   │   ├── dashboard.tsx          (770 lignes — ACCUEIL, ALERTES, SÉCURITÉ, SECRÉTARIAT)
    │   │   └── ui.tsx                 (136 lignes — briques partagées : cartes, badges, boutons)
    │   ├── lib/
    │   │   ├── fc-auth.ts             (130 lignes — JWT, hash PIN PBKDF2, helpers session)
    │   │   ├── fc-server.ts           (71 lignes — helpers serveur)
    │   │   └── fc-client.ts           (77 lignes — hooks client)
    │   └── hooks/                     use-toast, use-mobile
    ├── prisma/schema.prisma           (12 tables : Family, Branch, Member, User, Device, AccessCode, OtpCode, RecoveryCode, Challenge, Notification, NotificationPref, SecurityLog)
    ├── public/
    │   ├── logo-famille.png + logo.svg (LE logo de l'application)
    │   ├── icons/                     favicon 16/32, apple-touch 180, PWA 96/192/512 + maskable
    │   ├── manifest.webmanifest       (manifeste PWA installable)
    │   └── sw.js                      (service worker : notifications push + clic)
    ├── package.json, next.config.ts, tailwind.config.ts, …  (config complète exécutable)
```

---

## 2. Comment regarder chaque partie

### A. Les maquettes d'origine (le plus simple)
Double-cliquez sur les fichiers HTML → ils s'ouvrent directement dans votre navigateur, aucune installation.
- **Maquette_Interactive** : la vision « complète » d'origine (tous les univers U1-U7).
- **Pitch_Deck** : le storytelling du projet.

### B. L'interface actuelle (2 options)
1. **Sans rien installer** : ouvrez l'application dans le panneau de prévisualisation (elle tourne déjà).
2. **En local sur votre machine** (le dossier `02-interface-actuelle` est une application complète) :
   ```bash
   bun install        # ou npm install
   bun run db:push    # crée la base SQLite
   bun run dev        # http://localhost:3000
   ```

### C. Parcourir l'interface actuelle (flux de démonstration)
1. **Écran d'accueil** : logo + arbre familial en filigrane + bouton « J'ai un code d'accès ».
2. **Saisie du code** : format `FC-XXXX-XXXX` (code remis par le secrétaire, ou scanné par QR).
3. **Confirmation d'identité** : la fiche pré-enregistrée s'affiche (nom, branche, rôle) → « Oui, c'est moi ».
4. **Code OTP de démo** : 6 chiffres affichés À L'ÉCRAN (mode démo 0 FCFA — en production : SMS).
5. **Configuration post-activation** : biométrie (Passkey) + code de récupération personnel affiché UNE SEULE FOIS.
6. **Tableau de bord** : 4 onglets en bas (navigation mobile) —
   - **Accueil** : salutations personnalisées, actions rapides, dernières alertes
   - **Alertes** : centre de notifications (priorités couleur, tout lire, préférences digest 19h)
   - **Sécurité** : appareils connectés (révocation), journal des événements, code récupération
   - **Secrétariat** (réservé chef/secrétaire) : pré-enregistrement des membres + génération/régénération de codes

> **Reconnexion** (comme WhatsApp) : session persistante — pas de déconnexion sur mobile.
> Sur session web : déconnexion possible, reconnexion par PIN ou biométrie.

---

## 3. Rappel : notifications déjà câblées action par action

| Action | Toast instantané | Notification persistante (centre) |
|---|---|---|
| Code d'accès validé / refusé / expiré | ✔ info/succès/erreur | — (+ journal sécurité) |
| OTP demandé / validé / échoué | ✔ | — |
| Compte activé | ✔ | WELCOME (membre) + MEMBER_ACTIVATED (admins) |
| Ré-enrôlement (nouveau device) | ✔ | REENROLLED (membre) + alerte admins ; anciens appareils révoqués |
| Biométrie activée | ✔ | PASSKEY_ADDED |
| PIN défini | ✔ | PIN_SET |
| PIN échoué ×5 | ✔ | 🔴 HAUTE — PIN_LOCKED (verrou 30 min) |
| Appareil révoqué | ✔ | 🔴 HAUTE |
| Code de récupération utilisé | ✔ | 🔴 HAUTE + admins + nouveau code émis |
| Membre pré-enregistré | ✔ | Notification aux admins |
| Push de test | ✔ | ✔ notification système réelle |

---

## 4. Axes d'amélioration possibles (pour la discussion)

1. **Micro-animations** : transitions fluides entre écrans (slide/fade), vibration légère à la validation, confettis à l'activation du compte.
2. **Illustrations culturelles** : motifs wax/tissu camerounais discrets en arrière-plan de sections, avatars générés par branche familiale.
3. **Mode sombre** : le vert profond #1E4D2B s'y prête très bien (économise la batterie, lisible au soleil).
4. **Sons de notification** distincts par priorité (critique ≠ info) + badge d'icône PWA.
5. **Écrans restants** : la maquette d'origine couvre les univers U1-U7 (registre, finances, événements, patrimoine…) — à construire sur le même design system.
6. **Accessibilité renforcée** : tailles de police ajustables (aînés), mode contraste élevé, lecture vocale des alertes critiques.

---
*Pack généré automatiquement depuis le projet `/home/z/my-project` — FamilleConnect, « Le système d'exploitation numérique des grandes familles africaines ».*
