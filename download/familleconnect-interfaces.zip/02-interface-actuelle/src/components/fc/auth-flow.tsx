"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { startAuthentication, startRegistration } from "@simplewebauthn/browser";
import { api, deviceName, ensureDeviceSuffix } from "@/lib/fc-client";
import { FcButton, FcCard, FcDivider, FcInput, FcLogo, FcSpinner, FcTitle, FcWatermark } from "./ui";
import { Fingerprint, KeyRound, LifeBuoy, Lock, ShieldCheck, ArrowLeft, MailCheck, Copy, Check, RefreshCw } from "lucide-react";

type MemberInfo = { fullName: string; branch: string; role: string; phone: string | null; reenroll: boolean };

type Step =
  | { k: "welcome" }
  | { k: "code-entry" }
  | { k: "claim-confirm"; claimToken: string; member: MemberInfo }
  | { k: "otp"; claimToken: string; member: MemberInfo; demoCode?: string }
  | { k: "recovery-entry" }
  | { k: "pin-login"; uid: string; name: string; hasPasskey: boolean }
  | { k: "setup"; recoveryCode: string; userName: string; reenroll: boolean };

export function AuthFlow({ onReady }: { onReady: (name: string) => void }) {
  const [step, setStep] = useState<Step>({ k: "welcome" });
  const [busy, setBusy] = useState(false);
  const [remembered, setRemembered] = useState<{ uid: string; name: string; hasPasskey: boolean } | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      const uid = localStorage.getItem("fc_uid");
      const name = localStorage.getItem("fc_name");
      if (uid && name) {
        setRemembered({ uid, name, hasPasskey: localStorage.getItem("fc_has_passkey") === "1" });
      }
      ensureDeviceSuffix();
    }, 0);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="relative flex min-h-full flex-col items-center px-4 py-8 sm:py-12">
      <FcWatermark />

      {/* En-tête de marque — fidèle à la maquette */}
      <div className="relative z-10 w-full max-w-md rounded-b-[40px] pb-6 pt-2">
        <FcLogo size={132} />
      </div>

      <div className="relative z-10 w-full max-w-md space-y-4">
        {step.k === "welcome" && (
          <WelcomeScreen
            remembered={remembered}
            busy={busy}
            setBusy={setBusy}
            onReady={onReady}
            goto={setStep}
          />
        )}
        {step.k === "code-entry" && (
          <CodeEntryScreen busy={busy} setBusy={setBusy} goto={setStep} />
        )}
        {step.k === "claim-confirm" && (
          <ClaimConfirmScreen
            state={step}
            busy={busy}
            setBusy={setBusy}
            goto={setStep}
          />
        )}
        {step.k === "otp" && (
          <OtpScreen state={step} busy={busy} setBusy={setBusy} goto={setStep} onReady={onReady} />
        )}
        {step.k === "recovery-entry" && (
          <RecoveryEntryScreen busy={busy} setBusy={setBusy} goto={setStep} onReady={onReady} />
        )}
        {step.k === "pin-login" && (
          <PinLoginScreen state={step} busy={busy} setBusy={setBusy} goto={setStep} onReady={onReady} />
        )}
        {step.k === "setup" && (
          <SetupScreen state={step} busy={busy} setBusy={setBusy} onReady={onReady} />
        )}
      </div>
    </div>
  );
}

/* ───────────────────────── Écran d'accueil ───────────────────────── */

function WelcomeScreen({
  remembered,
  busy,
  setBusy,
  onReady,
  goto,
}: {
  remembered: { uid: string; name: string; hasPasskey: boolean } | null;
  busy: boolean;
  setBusy: (b: boolean) => void;
  onReady: (name: string) => void;
  goto: (s: Step) => void;
}) {
  const handleRealPasskey = useCallback(async () => {
    if (!remembered) return;
    setBusy(true);
    try {
      const { options } = await api<{ options: unknown }>("/api/auth/passkey", {
        body: { action: "auth-options" },
      });
      const response = await startAuthentication({ optionsJSON: options as never });
      const result = await api<{ user: { fullName: string } }>("/api/auth/passkey", {
        body: { action: "auth-verify", response },
      });
      if (!result.ok) throw new Error(result.error);
      localStorage.setItem("fc_uid", remembered.uid);
      localStorage.setItem("fc_name", result.user.fullName);
      toast.success(`Content de vous revoir, ${result.user.fullName.split(" ")[0]} !`);
      onReady(result.user.fullName);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Connexion biométrique impossible sur cet appareil.");
    } finally {
      setBusy(false);
    }
  }, [remembered, onReady, setBusy]);

  const handleSimulatedPasskey = useCallback(async () => {
    if (!remembered) return;
    setBusy(true);
    try {
      const result = await api<{ user: { fullName: string } }>("/api/auth/passkey", {
        body: { action: "simulate", uid: remembered.uid },
      });
      if (!result.ok) throw new Error(result.error);
      localStorage.setItem("fc_uid", remembered.uid);
      localStorage.setItem("fc_name", result.user.fullName);
      toast.success(`Content de vous revoir, ${result.user.fullName.split(" ")[0]} ! (biométrie simulée)`);
      onReady(result.user.fullName);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Échec de la connexion simulée.");
    } finally {
      setBusy(false);
    }
  }, [remembered, onReady, setBusy]);

  return (
    <FcCard className="p-6 sm:p-8">
      <FcTitle className="mb-1">FamilleConnect</FcTitle>
      <p className="mb-6 text-center text-[15px] text-[#5C6B60]">
        Le registre vivant de la Famille Mbeutetsa
      </p>

      {remembered && (
        <div className="mb-5 rounded-2xl border border-[#C89F62]/40 bg-[#C89F62]/10 p-4 text-center">
          <p className="text-sm text-[#7A5B2E]">
            Bon retour parmi nous, <span className="font-bold">{remembered.name}</span>
          </p>
        </div>
      )}

      {remembered && remembered.hasPasskey && (
        <div className="mb-3 space-y-2">
          <FcButton onClick={handleRealPasskey} disabled={busy}>
            {busy ? <FcSpinner /> : <Fingerprint className="h-5 w-5" />}
            Se connecter avec mon empreinte
          </FcButton>
          <FcButton variant="ghost" className="text-sm" onClick={handleSimulatedPasskey} disabled={busy}>
            <ShieldCheck className="h-4 w-4" /> Biométrie simulée (démo)
          </FcButton>
          <FcDivider label="ou" />
        </div>
      )}

      {remembered && (
        <div className="mb-3 space-y-2">
          <FcButton
            variant="outline"
            onClick={() => goto({ k: "pin-login", uid: remembered.uid, name: remembered.name, hasPasskey: remembered.hasPasskey })}
          >
            <Lock className="h-5 w-5" /> Mon code PIN
          </FcButton>
          <FcDivider label="nouvel appareil" />
        </div>
      )}

      <div className="space-y-2">
        <FcButton onClick={() => goto({ k: "code-entry" })} disabled={busy}>
          <KeyRound className="h-5 w-5" /> J&apos;ai un code d&apos;accès
        </FcButton>
        <FcButton variant="ghost" className="text-sm" onClick={() => goto({ k: "recovery-entry" })} disabled={busy}>
          <LifeBuoy className="h-4 w-4" /> Récupérer mon accès (code personnel)
        </FcButton>
      </div>

      <p className="mt-5 rounded-xl bg-[#3D6B52]/5 p-3 text-center text-[13px] leading-relaxed text-[#5C6B60]">
        Pas encore de code ? Le <strong>secrétaire de famille</strong> pré-enregistre chaque membre et remet
        un code d&apos;accès. Rendez-vous à la prochaine réunion, ou contactez-le.
      </p>
    </FcCard>
  );
}

/* ───────────────────────── Saisie du code d'accès ───────────────────────── */

function CodeEntryScreen({
  busy,
  setBusy,
  goto,
}: {
  busy: boolean;
  setBusy: (b: boolean) => void;
  goto: (s: Step) => void;
}) {
  const [code, setCode] = useState("");
  const handle = async () => {
    if (code.trim().length < 4) {
      toast.error("Entrez le code d'accès remis par le secrétaire (ex : FC-XXXX-XXXX).");
      return;
    }
    setBusy(true);
    try {
      const res = await api<{ claimToken: string; member: MemberInfo }>("/api/auth/verify-code", {
        body: { code, deviceName: deviceName() },
      });
      if (!res.ok) throw new Error(res.error);
      toast.success("Code validé ✓");
      goto({ k: "claim-confirm", claimToken: res.claimToken, member: res.member });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Code invalide.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <FcCard className="p-6 sm:p-8">
      <BackButton onClick={() => goto({ k: "welcome" })} />
      <h2 className="fc-serif mb-1 text-center text-2xl font-bold text-[#1E4D2B]">Code d&apos;accès</h2>
      <p className="mb-6 text-center text-[14px] text-[#5C6B60]">
        Saisissez le code remis par le secrétaire de famille.
      </p>
      <FcInput
        icon={<KeyRound className="h-5 w-5" />}
        placeholder="FC-XXXX-XXXX"
        value={code}
        onChange={(e) => setCode(e.target.value.toUpperCase())}
        onKeyDown={(e) => e.key === "Enter" && handle()}
        autoCapitalize="characters"
        autoComplete="one-time-code"
        className="mb-4"
        aria-label="Code d'accès"
      />
      <FcButton onClick={handle} disabled={busy}>
        {busy ? <FcSpinner /> : "Vérifier mon code"}
      </FcButton>
    </FcCard>
  );
}

/* ───────────────────────── Confirmation du profil pré-enregistré ───────────────────────── */

function ClaimConfirmScreen({
  state,
  busy,
  setBusy,
  goto,
}: {
  state: Extract<Step, { k: "claim-confirm" }>;
  busy: boolean;
  setBusy: (b: boolean) => void;
  goto: (s: Step) => void;
}) {
  const m = state.member;
  const confirm = async () => {
    setBusy(true);
    try {
      goto({ k: "otp", claimToken: state.claimToken, member: m });
    } finally {
      setBusy(false);
    }
  };
  return (
    <FcCard className="p-6 sm:p-8">
      <BackButton onClick={() => goto({ k: "code-entry" })} />
      <h2 className="fc-serif mb-1 text-center text-2xl font-bold text-[#1E4D2B]">
        {m.reenroll ? "Réactiver mon accès" : "C'est vous ?"}
      </h2>
      <p className="mb-5 text-center text-[14px] text-[#5C6B60]">
        {m.reenroll
          ? "Nouvel appareil détecté. Vos anciens appareils seront déconnectés."
          : "Le secrétaire a pré-enregistré ce profil. Confirmez votre identité."}
      </p>
      <div className="mb-6 space-y-2 rounded-2xl border border-[#E5DCC0] bg-[#FFFDF6] p-4">
        <Row label="Nom" value={m.fullName} strong />
        <Row label="Branche" value={m.branch} />
        <Row label="Rôle" value={roleLabel(m.role)} />
        {m.phone && <Row label="Téléphone" value={m.phone} />}
      </div>
      <FcButton onClick={confirm} disabled={busy}>
        {busy ? <FcSpinner /> : <MailCheck className="h-5 w-5" />}
        Oui, c&apos;est moi — continuer
      </FcButton>
      <button
        className="mt-3 w-full text-center text-sm text-[#B91C1C] hover:underline"
        onClick={() => {
          toast.info("Ce n'est pas vous ? Ne poursuivez pas et signalez-le au secrétaire de famille.");
          goto({ k: "welcome" });
        }}
      >
        Ce n&apos;est pas moi
      </button>
    </FcCard>
  );
}

/* ───────────────────────── Vérification OTP (mode démo) ───────────────────────── */

function OtpScreen({
  state,
  busy,
  setBusy,
  goto,
  onReady,
}: {
  state: Extract<Step, { k: "otp" }>;
  busy: boolean;
  setBusy: (b: boolean) => void;
  goto: (s: Step) => void;
  onReady: (name: string) => void;
}) {
  const [code, setCode] = useState("");
  const [demoCode, setDemoCode] = useState<string | undefined>(state.demoCode);
  const requested = useRef(false);

  const requestCode = useCallback(async () => {
    setBusy(true);
    try {
      const res = await api<{ demoMode: boolean; demoCode?: string }>("/api/auth/otp", {
        body: { action: "request", claimToken: state.claimToken },
      });
      if (!res.ok) throw new Error(res.error);
      if (res.demoCode) {
        setDemoCode(res.demoCode);
        toast.info(`Mode démo — votre code de vérification : ${res.demoCode}`);
      } else {
        toast.success("Code de vérification envoyé par SMS.");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Envoi du code impossible.");
    } finally {
      setBusy(false);
    }
  }, [state.claimToken, setBusy]);

  useEffect(() => {
    if (!requested.current) {
      requested.current = true;
      requestCode();
    }
  }, [requestCode]);

  const verify = async () => {
    setBusy(true);
    try {
      const res = await api<{ activateToken: string }>("/api/auth/otp", {
        body: { action: "verify", claimToken: state.claimToken, code },
      });
      if (!res.ok) throw new Error(res.error);
      const activation = await api<{ recoveryCode: string; user: { fullName: string }; reenroll: boolean }>(
        "/api/auth/activate",
        { body: { activateToken: res.activateToken } }
      );
      if (!activation.ok) throw new Error(activation.error);
      localStorage.setItem("fc_uid", activation.user.id);
      localStorage.setItem("fc_name", activation.user.fullName);
      localStorage.removeItem("fc_has_passkey");
      toast.success(activation.reenroll ? "Accès réactivé ✓" : "Compte activé ✓ Bienvenue !");
      goto({ k: "setup", recoveryCode: activation.recoveryCode, userName: activation.user.fullName, reenroll: activation.reenroll });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Code incorrect.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <FcCard className="p-6 sm:p-8">
      <BackButton onClick={() => goto({ k: "code-entry" })} />
      <h2 className="fc-serif mb-1 text-center text-2xl font-bold text-[#1E4D2B]">Vérification</h2>
      <p className="mb-5 text-center text-[14px] text-[#5C6B60]">
        Entrez le code à 6 chiffres envoyé pour {state.member.fullName}.
      </p>

      {demoCode && (
        <div className="mb-4 rounded-2xl border border-dashed border-[#C89F62] bg-[#C89F62]/10 p-4 text-center">
          <p className="text-xs font-semibold uppercase tracking-wide text-[#7A5B2E]">Mode démo — votre code</p>
          <p className="fc-serif text-3xl font-bold tracking-[0.35em] text-[#1E4D2B]">{demoCode}</p>
        </div>
      )}

      <FcInput
        icon={<MailCheck className="h-5 w-5" />}
        placeholder="● ● ● ● ● ●"
        value={code}
        onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
        onKeyDown={(e) => e.key === "Enter" && code.length === 6 && verify()}
        inputMode="numeric"
        autoComplete="one-time-code"
        maxLength={6}
        className="mb-4 text-center tracking-[0.4em]"
        aria-label="Code de vérification à 6 chiffres"
      />
      <FcButton onClick={verify} disabled={busy || code.length !== 6}>
        {busy ? <FcSpinner /> : "Vérifier"}
      </FcButton>
      <button
        className="mt-3 flex w-full items-center justify-center gap-1.5 text-sm text-[#C89F62] hover:underline"
        onClick={() => {
          setCode("");
          requestCode();
        }}
        disabled={busy}
      >
        <RefreshCw className="h-3.5 w-3.5" /> Renvoyer un nouveau code
      </button>
    </FcCard>
  );
}

/* ───────────────────────── Code de récupération ───────────────────────── */

function RecoveryEntryScreen({
  busy,
  setBusy,
  goto,
  onReady,
}: {
  busy: boolean;
  setBusy: (b: boolean) => void;
  goto: (s: Step) => void;
  onReady: (name: string) => void;
}) {
  const [code, setCode] = useState("");
  const handle = async () => {
    setBusy(true);
    try {
      const res = await api<{
        user: { id: string; fullName: string };
        newRecoveryCode: string;
      }>("/api/auth/recovery", { body: { code, deviceName: deviceName() } });
      if (!res.ok) throw new Error(res.error);
      localStorage.setItem("fc_uid", res.user.id);
      localStorage.setItem("fc_name", res.user.fullName);
      localStorage.removeItem("fc_has_passkey");
      toast.success("Accès récupéré ✓ Anciens appareils déconnectés.");
      goto({ k: "setup", recoveryCode: res.newRecoveryCode, userName: res.user.fullName, reenroll: true });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Code invalide.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <FcCard className="p-6 sm:p-8">
      <BackButton onClick={() => goto({ k: "welcome" })} />
      <h2 className="fc-serif mb-1 text-center text-2xl font-bold text-[#1E4D2B]">Récupérer mon accès</h2>
      <p className="mb-6 text-center text-[14px] text-[#5C6B60]">
        Saisissez votre <strong>code de récupération personnel</strong> (format MBTE-XXXX-XXXX). Il a été affiché
        une seule fois à votre première inscription.
      </p>
      <FcInput
        icon={<LifeBuoy className="h-5 w-5" />}
        placeholder="MBTE-XXXX-XXXX"
        value={code}
        onChange={(e) => setCode(e.target.value.toUpperCase())}
        onKeyDown={(e) => e.key === "Enter" && handle()}
        autoCapitalize="characters"
        className="mb-4"
        aria-label="Code de récupération"
      />
      <FcButton onClick={handle} disabled={busy}>
        {busy ? <FcSpinner /> : "Récupérer mon accès"}
      </FcButton>
      <p className="mt-4 text-center text-[13px] text-[#8A9288]">
        Code perdu ? Le secrétaire de famille peut régénérer un code d&apos;accès pour vous.
      </p>
    </FcCard>
  );
}

/* ───────────────────────── Connexion par PIN ───────────────────────── */

function PinLoginScreen({
  state,
  busy,
  setBusy,
  goto,
  onReady,
}: {
  state: Extract<Step, { k: "pin-login" }>;
  busy: boolean;
  setBusy: (b: boolean) => void;
  goto: (s: Step) => void;
  onReady: (name: string) => void;
}) {
  const [pin, setPin] = useState("");
  const handle = async () => {
    setBusy(true);
    try {
      const res = await api<{ user: { id: string; fullName: string } }>("/api/auth/pin", {
        body: { action: "verify", uid: state.uid, pin, deviceName: deviceName() },
      });
      if (!res.ok) throw new Error(res.error);
      localStorage.setItem("fc_uid", res.user.id);
      localStorage.setItem("fc_name", res.user.fullName);
      toast.success(`Content de vous revoir, ${res.user.fullName.split(" ")[0]} !`);
      onReady(res.user.fullName);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "PIN incorrect.");
      setPin("");
    } finally {
      setBusy(false);
    }
  };
  return (
    <FcCard className="p-6 sm:p-8">
      <BackButton onClick={() => goto({ k: "welcome" })} />
      <h2 className="fc-serif mb-1 text-center text-2xl font-bold text-[#1E4D2B]">Code PIN</h2>
      <p className="mb-6 text-center text-[14px] text-[#5C6B60]">
        Votre PIN de secours, {state.name.split(" ")[0]}.
      </p>
      <FcInput
        icon={<Lock className="h-5 w-5" />}
        placeholder="● ● ● ●"
        value={pin}
        onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
        onKeyDown={(e) => e.key === "Enter" && pin.length >= 4 && handle()}
        inputMode="numeric"
        type="password"
        maxLength={6}
        className="mb-4 text-center tracking-[0.4em]"
        aria-label="Code PIN"
      />
      <FcButton onClick={handle} disabled={busy || pin.length < 4}>
        {busy ? <FcSpinner /> : "Se connecter"}
      </FcButton>
      <p className="mt-4 text-center text-[13px] text-[#8A9288]">
        5 tentatives maximum, puis verrouillage de 30 minutes.
      </p>
    </FcCard>
  );
}

/* ───────────────────────── Écran de premières étapes (post-activation) ───────────────────────── */

function SetupScreen({
  state,
  busy,
  setBusy,
  onReady,
}: {
  state: Extract<Step, { k: "setup" }>;
  busy: boolean;
  setBusy: (b: boolean) => void;
  onReady: (name: string) => void;
}) {
  const [ack, setAck] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pin, setPin] = useState("");
  const [pinDone, setPinDone] = useState(false);
  const [bioDone, setBioDone] = useState(false);
  const [bioSimulated, setBioSimulated] = useState(false);

  const copyRecovery = async () => {
    await navigator.clipboard.writeText(state.recoveryCode).catch(() => {});
    setCopied(true);
    toast.success("Code de récupération copié — collez-le dans un endroit sûr.");
  };

  const savePin = async () => {
    setBusy(true);
    try {
      const res = await api("/api/auth/pin", { body: { action: "setup", pin } });
      if (!res.ok) throw new Error(res.error);
      setPinDone(true);
      toast.success("Code PIN enregistré ✓");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Échec de l'enregistrement du PIN.");
    } finally {
      setBusy(false);
    }
  };

  const enrollBiometry = async () => {
    setBusy(true);
    try {
      const { options } = await api<{ options: unknown }>("/api/auth/passkey", {
        body: { action: "register-options" },
      });
      const response = await startRegistration({ optionsJSON: options as never });
      const result = await api("/api/auth/passkey", {
        body: { action: "register-verify", response, deviceLabel: deviceName() },
      });
      if (!result.ok) throw new Error(result.error);
      setBioDone(true);
      localStorage.setItem("fc_has_passkey", "1");
      toast.success("Biométrie activée ✓ Vous vous connecterez d'un simple geste.");
    } catch (e) {
      toast.error(
        e instanceof Error
          ? `Biométrie indisponible ici (${e.message.slice(0, 60)}). Utilisez le mode démo ci-dessous.`
          : "Biométrie indisponible."
      );
    } finally {
      setBusy(false);
    }
  };

  const simulateBiometry = async () => {
    setBusy(true);
    try {
      const result = await api("/api/auth/passkey", { body: { action: "simulate-register" } });
      if (!result.ok) throw new Error(result.error);
      setBioDone(true);
      setBioSimulated(true);
      localStorage.setItem("fc_has_passkey", "0");
      toast.success("Appareil biométrique simulé enregistré (mode démo) ✓");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Simulation impossible.");
    } finally {
      setBusy(false);
    }
  };

  const enter = () => {
    if (!ack) {
      toast.error("Confirmez d'abord avoir noté votre code de récupération.");
      return;
    }
    onReady(state.userName);
  };

  return (
    <div className="space-y-4">
      {/* 1. Code de récupération */}
      <FcCard className="p-6">
        <div className="mb-2 flex items-center gap-2">
          <LifeBuoy className="h-5 w-5 text-[#D97706]" />
          <h2 className="fc-serif text-xl font-bold text-[#1E4D2B]">Votre code de récupération</h2>
        </div>
        <p className="mb-3 text-[13px] leading-relaxed text-[#5C6B60]">
          {state.reenroll
            ? "Un NOUVEAU code vous a été attribué (l'ancien est invalidé)."
            : "C'est la seule fois où il sera affiché."}{" "}
          Notez-le sur papier ou envoyez-le-vous par WhatsApp. Il permet de récupérer votre accès si vous perdez
          votre téléphone.
        </p>
        <div className="mb-3 flex items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-[#D97706] bg-[#D97706]/5 p-4">
          <span className="fc-serif text-2xl font-bold tracking-wider text-[#7A5B2E]">{state.recoveryCode}</span>
          <button
            onClick={copyRecovery}
            className="rounded-lg p-2 text-[#C89F62] hover:bg-[#C89F62]/10"
            aria-label="Copier le code de récupération"
          >
            {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
          </button>
        </div>
        <label className="flex cursor-pointer items-start gap-2 text-[14px] text-[#2B3530]">
          <input
            type="checkbox"
            checked={ack}
            onChange={(e) => setAck(e.target.checked)}
            className="mt-0.5 h-4 w-4 accent-[#1F5B3F]"
          />
          <span>J&apos;ai noté mon code de récupération en lieu sûr.</span>
        </label>
      </FcCard>

      {/* 2. PIN de secours */}
      <FcCard className="p-6">
        <div className="mb-2 flex items-center gap-2">
          <Lock className="h-5 w-5 text-[#2A4A3A]" />
          <h2 className="fc-serif text-xl font-bold text-[#1E4D2B]">Code PIN de secours</h2>
        </div>
        {pinDone ? (
          <p className="text-sm font-medium text-[#16A34A]">✓ PIN défini — il déverrouille cet appareil.</p>
        ) : (
          <>
            <p className="mb-3 text-[13px] text-[#5C6B60]">
              4 à 6 chiffres, mémorisable. Sert quand la biométrie est indisponible. (Recommandé, mais optionnel.)
            </p>
            <div className="flex gap-2">
              <FcInput
                placeholder="● ● ● ●"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                inputMode="numeric"
                type="password"
                maxLength={6}
                className="flex-1"
                aria-label="Nouveau code PIN"
              />
              <FcButton onClick={savePin} disabled={busy || pin.length < 4} className="w-auto px-6">
                Définir
              </FcButton>
            </div>
          </>
        )}
      </FcCard>

      {/* 3. Biométrie */}
      <FcCard className="p-6">
        <div className="mb-2 flex items-center gap-2">
          <Fingerprint className="h-5 w-5 text-[#2A4A3A]" />
          <h2 className="fc-serif text-xl font-bold text-[#1E4D2B]">Connexion par empreinte</h2>
        </div>
        {bioDone ? (
          <p className="text-sm font-medium text-[#16A34A]">
            ✓ {bioSimulated ? "Appareil simulé enregistré (démo)" : "Biométrie active sur cet appareil"}
          </p>
        ) : (
          <div className="space-y-2">
            <p className="mb-2 text-[13px] text-[#5C6B60]">
              Un geste = connecté, pour toujours. Zéro mot de passe à retenir.
            </p>
            <FcButton onClick={enrollBiometry} disabled={busy}>
              {busy ? <FcSpinner /> : <Fingerprint className="h-5 w-5" />} Activer mon empreinte
            </FcButton>
            <FcButton variant="outline" onClick={simulateBiometry} disabled={busy}>
              <ShieldCheck className="h-4 w-4" /> Simuler sur cet appareil (démo)
            </FcButton>
          </div>
        )}
      </FcCard>

      <FcButton onClick={enter} className="h-[54px] text-[17px]">
        Entrer dans FamilleConnect
      </FcButton>
    </div>
  );
}

/* ───────────────────────── Utilitaires partagés ───────────────────────── */

function BackButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="mb-2 inline-flex items-center gap-1 text-sm text-[#5C6B60] hover:text-[#2A4A3A]"
      aria-label="Retour"
    >
      <ArrowLeft className="h-4 w-4" /> Retour
    </button>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 text-[14px]">
      <span className="text-[#8A9288]">{label}</span>
      <span className={strong ? "font-bold text-[#1E4D2B]" : "font-medium text-[#2B3530]"}>{value}</span>
    </div>
  );
}

export function roleLabel(role: string): string {
  const map: Record<string, string> = {
    PATRIARCHE: "Patriarche",
    CONSEIL: "Conseil de famille",
    CHEF_BRANCHE: "Chef de branche",
    SECRETAIRE: "Secrétaire de famille",
    ADULTE: "Adulte (18+)",
    JUNIOR: "Junior (moins de 18 ans)",
  };
  return map[role] ?? role;
}
